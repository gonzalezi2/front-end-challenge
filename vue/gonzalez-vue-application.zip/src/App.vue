<template>
  <div class="container">
    <dashboard></dashboard>
  </div>
</template>

<script>
import Dashboard from './components/Dashboard';

export default {
  name: 'App',
  components: {
    Dashboard
  }
}
</script>
